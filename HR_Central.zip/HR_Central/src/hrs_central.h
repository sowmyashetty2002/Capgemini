#include <zephyr/types.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <stdint.h>

#include <stdio.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>


#define STACKSIZE 1024

#define KEY_PRINT1_MASK DK_BTN1_MSK
#define KEY_PRINT2_MASK DK_BTN2_MSK
#define KEY_PRINT3_MASK DK_BTN3_MSK
#define KEY_PRINT4_MASK DK_BTN4_MSK

#define KEY_READVAL1_MASK DK_BTN1_MSK
#define KEY_READVAL2_MASK DK_BTN2_MSK
#define KEY_READVAL3_MASK DK_BTN3_MSK
#define KEY_READVAL4_MASK DK_BTN4_MSK


#define RUN_STATUS_LED             DK_LED1
#define CENTRAL_CON_STATUS_LED	   DK_LED2




#define HRS_QUEUE_SIZE 16

static struct bt_hrs_client hrs_c;
static struct bt_conn *central_conn;


static int flag=1;
static struct bt_scan_device_info *dev_info = NULL;
//static char flag_addr[BT_ADDR_LE_STR_LEN];

const bt_addr_le_t *flag_addr = NULL;
bt_addr_le_t copied_addr;
static int flag_notify=0;



K_MSGQ_DEFINE(hrs_queue, sizeof(struct bt_hrs_client_measurement), HRS_QUEUE_SIZE, 4);


static void button_handler(uint32_t button_state, uint32_t has_changed);

static const struct bt_conn_auth_cb auth_callbacks;

static const char * const sensor_location_str[] = {
	"Other",
	"Chest",
	"Wrist",
	"Finger",
	"Hand",
	"Ear lobe",
	"Foot"
};   