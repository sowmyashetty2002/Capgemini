/** @file
 *  @brief Heart rate service client sample
*/

/*
 * copyright (c) 2023 capgemini corporation
 * 
 * SPDX-license-Identifier: Apache-2.0
*/


#include <zephyr/types.h>
#include <stddef.h>
#include <inttypes.h>
#include <errno.h>
#include <zephyr/sys/printk.h>
#include <zephyr/kernel.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/hci.h>
#include <bluetooth/scan.h>
#include <bluetooth/gatt_dm.h>

#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/bluetooth/services/hrs.h>
#include <bluetooth/services/hrs_client.h>

#include <dk_buttons_and_leds.h>

#include <zephyr/settings/settings.h>
#include <zephyr/logging/log.h>

#include <stdio.h>
#include <stdlib.h>

#include "hrs_central.h"


/**@brief  Callback function for reading the Heart Rate Sensor (HRS) body location. 
 * 
 * This function is called when the HRS client receives a response 
 * for the body location read request
 * 
 * @param hrs_c The HRS client instance
 * 
 * @param location The sensor location value indicating the position of the heart rate sensor on the body.
 * 
 * @param err  The error code (0 if no error occurred).
 * 
 */ 
static void hrs_sensor_location_read_cb(struct bt_hrs_client *hrs_c,
					enum bt_hrs_client_sensor_location location,
					int err)
{
	if (err) {
		printk("HRS Sensor Body Location read error (err %d)\n", err);
		return;
	}
	printk("Heart Rate Sensor body location: %s\n", sensor_location_str[location]);
}

/**@brief Callback function for receiving Heart Rate Measurement notifications.
 * 
 * @param hrs_c The HRS client instance.
 *  
 * @param meas Pointer to the Heart Rate Measurement structure containing the received measurement data.
 * 
 * @param err  The error code (0 if no error occurred).
 * 
 */ 
static void hrs_measurement_notify_cb(struct bt_hrs_client *hrs_c,
				      const struct bt_hrs_client_measurement *meas,
				      int err)
{
	if (err) {
		printk("Error during receiving Heart Rate Measurement notification, err: %d\n",
			err);
		return;
	}

	printk("Heart Rate Measurement notification received:\n\n");
	printk("\tHeart Rate Measurement Value Format: %s\n",
		meas->flags.value_format ? "16 - bit" : "8 - bit");
	printk("\tSensor Contact detected: %d\n", meas->flags.sensor_contact_detected);
	printk("\tSensor Contact supported: %d\n", meas->flags.sensor_contact_supported);
	printk("\tEnergy Expended present: %d\n", meas->flags.energy_expended_present);
	printk("\tRR-Intervals present: %d\n", meas->flags.rr_intervals_present);

	printk("\n\tHeart Rate Measurement Value: %d bpm\n", meas->hr_value);

	if (meas->flags.energy_expended_present) {
		printk("\n\tEnergy Expended: %d J\n", meas->energy_expended);
	}

	if (meas->flags.rr_intervals_present) {
		printk("\t RR-intervals: ");
		for (size_t i = 0; i < meas->rr_intervals_count; i++) {
			printk("%d ", meas->rr_intervals[i]);
		}
	}

	printk("\n");

	err = k_msgq_put(&hrs_queue, meas, K_NO_WAIT);
	if (err) {
		printk("Notification queue is full. Discarting HRS notification (err %d)\n", err);
	}
}

/**@brief Callback function for handling scan filter matches.
 * 
 * This function is called when a device's advertising data matches the specified scan filter criteria.
 * 
 * @param device_info Pointer to the device information structure containing details about the matched device.
 * 
 * @param filter_match  Pointer to the scan filter match structure containing information about the matched filter.
 * 
 * @param connectable  Boolean indicating whether the device is connectable or not.
 * 
 */ 
static void scan_filter_match(struct bt_scan_device_info *device_info,
			      struct bt_scan_filter_match *filter_match,
			      bool connectable)
{
	char addr[BT_ADDR_LE_STR_LEN];
	//char addr1[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(device_info->recv_info->addr, addr, sizeof(addr));

	printk("Filters matched. Address: %s connectable: %s\n",
		   addr, connectable ? "yes" : "no");

	flag_addr = device_info->recv_info->addr;

//bt_addr_le_to_str(flag_addr, addr1, sizeof(addr1));
	//printk("flag variable address %s\n",addr1);

	bt_scan_stop();

	dev_info = device_info;

	memcpy(&copied_addr, flag_addr, sizeof(bt_addr_le_t));
}


/**@brief Callback function for handling connecting errors during scanning.
 * 
 * This function is called when a connection attempt to a device encountered an error.
 * 
 * @param device_info Pointer to the device information structure containing details about
 *                    the device that failed to connect.
 * 
 */ 
static void scan_connecting_error(struct bt_scan_device_info *device_info)
{
	printk("Connecting failed\n");
}

/**@brief  Callback function for handling successful connection establishment during scanning.
 * 
 * @param device_info  Pointer to the device information structure containing details about the connected device.
 *  
 * @param conn Pointer to the established connection object.
 * 
 */
static void scan_connecting(struct bt_scan_device_info *device_info,
			    struct bt_conn *conn)
{
	central_conn = bt_conn_ref(conn);
}

/**@brief Callback function for handling scan filter no matches.
 * 
 * This function is called when a device's advertising data does not match the specified scan filter criteria.
 *  
 * @param device_info Pointer to the device information structure containing details about the unmatched device.
 *  
 * @param connectable Boolean indicating whether the device is connectable or not.
 * 
 */ 
static void scan_filter_no_match(struct bt_scan_device_info *device_info,
				 bool connectable)
{
	int err;
	char addr[BT_ADDR_LE_STR_LEN];

	if (device_info->recv_info->adv_type == BT_GAP_ADV_TYPE_ADV_DIRECT_IND) {

		bt_addr_le_to_str(device_info->recv_info->addr, addr,
				  sizeof(addr));
		printk("Direct advertising received from %s\n", addr);
		dev_info = device_info;
		
		bt_scan_stop();

 	}
}
 
BT_SCAN_CB_INIT(scan_cb, scan_filter_match,scan_filter_no_match,
		scan_connecting_error, scan_connecting);

/**@brief  Callback function for the completion of GATT service discovery.
 * 
 * @param dm   Discovery instance.
 * 
 * @param context The user context.
 * 
 */ 
static void discovery_completed_cb(struct bt_gatt_dm *dm,
				   void *context)
{
	int err;
	printk("The discovery procedure succeeded\n");
	bt_gatt_dm_data_print(dm);
	err = bt_hrs_client_handles_assign(dm, &hrs_c);
	if (err) {
		printk("Could not init HRS client object (err %d)\n", err);
		return;
	}
}

/**@brief Callback function for handling the failure to find the Heart Rate Service 
 *        during GATT service discovery.
 * 
 * @param conn Pointer to the connection object associated with the failed discovery.
 * 
 * @param context User-defined context data.
 * 
 */
static void discovery_not_found_cb(struct bt_conn *conn,
				   void *context)
{
	printk("Heart Rate Service could not be found during the discovery\n");
}

/**@brief Callback function for handling errors encountered during GATT service discovery.
 * 
 * @param conn Pointer to the connection object associated with the failed discovery.
 * 
 * @param err The error code indicating the reason for the discovery failure.
 * 
 * @param context  User-defined context data.
 * 
 */
static void discovery_error_found_cb(struct bt_conn *conn,
				     int err, void *context)
{
	printk("The discovery procedure failed with %d\n", err);
}

static const struct bt_gatt_dm_cb discovery_cb = {
	.completed = discovery_completed_cb,
	.service_not_found = discovery_not_found_cb,
	.error_found = discovery_error_found_cb
};

/**@brief Function for initiating GATT service discovery.
 * 
 * This function starts the GATT service discovery procedure for the specified connection.
 * 
 * @param conn Pointer to the connection object for which GATT service discovery is to be initiated.
 * 
 */ 
static void gatt_discover(struct bt_conn *conn)
{
	int err;

	err = bt_gatt_dm_start(conn, BT_UUID_HRS, &discovery_cb, NULL);
	if (err) {
		printk("Could not start the discovery procedure, error "
			   "code: %d\n", err);
	}
}

/**@brief Function for starting the Bluetooth scanning process.
 * 
 * This function starts the Bluetooth scanning process if it has not been started already.
 * 
 * @return The current state of the scanning process (flag value).
 * 
 */
static int scan_start(void)
{
		if(flag==1)
		{
			int err = bt_scan_start(BT_SCAN_TYPE_SCAN_PASSIVE);
			printk("scanning started\n");
			flag++;
		}
		else
		{
			printk("already started\n");
		}
	
	return flag;
}

/**@brief  Callback function for handling successful connection establishment.
 *  
 * @param conn Pointer to the connection object associated with the established connection.
 * 
 * @param conn_err The error code indicating the result of the connection establishment.
 * 
 */ 
static void connected(struct bt_conn *conn, uint8_t conn_err)
{
	int err;
	struct bt_conn_info info;
	char addr2[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr2, sizeof(addr2));
	//printk("connecetd device address %s\n",addr2);

	if (conn_err) {
		printk("Failed to connect to %s ------(%u)\n", addr2, conn_err);

		if (conn == central_conn) {
			bt_conn_unref(central_conn);
			central_conn = NULL;
			scan_start();
		}
		return;
	}

	printk("Connected: %s\n", addr2);
	bt_conn_get_info(conn, &info);

	if (info.role == BT_CONN_ROLE_CENTRAL) {
		dk_set_led_on(CENTRAL_CON_STATUS_LED);
		err = bt_conn_set_security(conn, BT_SECURITY_L2);
		if (err) {
			printk("Failed to set security (err %d)\n", err);
			gatt_discover(conn);
		}
	} 
}

/**@brief Callback function for handling disconnection events.
 * 
 * This function is called when a disconnection event occurs with a device
 * 
 * @param conn Pointer to the connection object associated with the disconnected device.
 * 
 * @param reason The reason code indicating the cause of the disconnection.
 * 
 */
static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Disconnected: %s (reason %u)\n", addr, reason);

	if (conn == central_conn) {
		dk_set_led_off(CENTRAL_CON_STATUS_LED);
		bt_conn_unref(central_conn);
		central_conn = NULL;
 		printk("press button1 to restart scanning\n");
  		flag=1;
	} 
}

/**@brief Callback function for handling changes in security level.
 * 
 * @param conn Pointer to the connection object for which the security level has changed.
 * 
 * @param level The new security level.
 * 
 * @param err The error code indicating the result of the security level change.
 * 
 */  
static void security_changed(struct bt_conn *conn, bt_security_t level,
			     enum bt_security_err err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (!err) {
		printk("Security changed: %s level %u\n", addr, level);
	} else {
		printk("Security failed: %s level %u err %d\n", addr, level,
			err);
	}

	if (conn == central_conn) {
		gatt_discover(conn);
	}
}

BT_CONN_CB_DEFINE(conn_callbacks)={
	.connected=connected,
	.disconnected=disconnected,
	.security_changed=security_changed
};

/**@brief Function for initializing Bluetooth scanning.
 * 
 * This function initializes Bluetooth scanning by setting up the scan parameters, 
 * registering the scan callback, adding the scan filter for the Heart Rate Service (HRS) UUID, 
 * and enabling the scan filter.
 * 
 */  
static void scan_init(void)
{
	int err;

	struct bt_scan_init_param param = {
		.scan_param = NULL,
		.conn_param = BT_LE_CONN_PARAM_DEFAULT,
	};
    
	bt_scan_init(&param);
	bt_scan_cb_register(&scan_cb);

	err = bt_scan_filter_add(BT_SCAN_FILTER_TYPE_UUID, BT_UUID_HRS);
	if (err) {
		printk("Scanning filters cannot be set (err %d)\n", err);
	}

	err = bt_scan_filter_enable(BT_SCAN_UUID_FILTER, false);
	if (err) {
		printk("Filters cannot be turned on (err %d)\n", err);
	}
}

/**@brief  Function for handling button press event for Button 1.
 * 
 * When button1 is pressed it will start scanning.
 * 
 */ 
static void button_readval1(void)
{
	printf("\n\n");
	int err;
	printk("Button1 pressed\n");
	scan_init();
	err=scan_start();
	if(err){
		return;
	}
	printk("scanning started\n");
}

/**@brief Function for handling button press event for Button 2.
 * 
 * This function is called when Button 2 is pressed.
 * 
 * When button2 is pressed it will initiate a connection procedure.
 */
static void button_readval2(void)
{

	printk("\n\n");
	printk("button2 pressed\n");
	struct bt_conn *conn;

	char addr3[BT_ADDR_LE_STR_LEN];
	//bt_addr_le_to_str(&copied_addr, addr3, sizeof(addr3));
	//printk("address in button2 is %s\n",addr3);

	struct bt_le_conn_param conn_param;
	conn_param.interval_min = 30;
	conn_param.interval_max = 50;
	conn_param.latency = 0;
	conn_param.timeout = 400;

	//printk("device info %p\n",dev_info);

	if (dev_info != NULL){

		int err;
		
		err = bt_conn_le_create(&copied_addr, BT_CONN_LE_CREATE_CONN, &conn_param, &conn);

		//bt_addr_le_to_str(&copied_addr, addr3, sizeof(addr3));

	//	printk("address in button2 is %s\n",addr3);

		if (!err) {
			central_conn = bt_conn_ref(conn);
			bt_conn_unref(conn);
			printk("connection initiated\n");		
		}
		else
		{
			printk("failed to initiate connection(err %d)\n",err);
		}
	}
	else
	{
		printk("no device information\n");
	} 
}

/**@brief Function for handling button press event for Button 3.
 * 
 * This function is called when Button 3 is pressed.
 * 
 * when button3 is pressed it will call the read callback function.It will print the Heart rate
 * sensor location.
 */ 
static void button_readval3(void)
{
	printk("\n\n");
	printk("button3 pressed:)\n");
	int err;
	printk("reading heart rate value\n");
	err=bt_hrs_client_sensor_location_read(&hrs_c,hrs_sensor_location_read_cb);
	if(err){
		printk("heart rate read call error : %d\n",err);
	}
}

/**@brief Function for handling button press event for Button 4.
 * 
 * This function is called when Button 4 is pressed.
 * 
 * When button4 is pressed,it will enable or disable the notification.
 */ 
static void button_readval4(void)
{
	printk("\n\n");
	printk("button4 pressed:)\n");
	int err;

		if(flag_notify % 2 == 0)
		{
			printk("Enabaling notification\n");
			err=bt_hrs_client_measurement_subscribe(&hrs_c,hrs_measurement_notify_cb);
			if(err){
			printk("heart rate notification error: %d\n",err);
			}
		}
		else
		{
			printk("disabling notification\n");
			err = bt_hrs_client_measurement_unsubscribe(&hrs_c);
			if(err){
			printk("heart rate notification disabling error: %d\n",err);
			}
		}
		flag_notify++;
}

/**@brief Function for handling button events.
 * 
 * This function is called when there are changes in the button state.
 * 
 * @param button_state  The current state of the buttons.
 * 
 * @param has_changed The buttons that have changed their state.
 * 
 */
static void button_handler(uint32_t button_state, uint32_t has_changed)
{
	uint32_t button = button_state & has_changed;

	if(button & KEY_READVAL1_MASK)
	{
		button_readval1();	
	}

	if(button & KEY_READVAL2_MASK)
	{
		button_readval2();
	}

	if(button & KEY_READVAL3_MASK)
	{
		button_readval3();
	}
	
	if(button & KEY_READVAL4_MASK)
	{
		button_readval4();
	}

}

/**@brief Callback function for canceling the authentication process.
 * 
 * This function is called when the authentication process is canceled.
 * 
 * @param conn Pointer to the connection object for which the authentication process is canceled.
 * 
 */ 
static void auth_cancel(struct bt_conn *conn)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing cancelled: %s\n", addr);
}

/**@brief Callback function for handling pairing completion.
 * 
 * This function is called when the pairing process is completed.
 * 
 * @param conn Pointer to the connection object for which the pairing process is completed.
 * 
 * @param bonded Boolean value indicating whether the devices are bonded (paired) or not.
 * 
 */ 
static void pairing_complete(struct bt_conn *conn, bool bonded)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing completed: %s, bonded: %d\n", addr, bonded);
}

/**@brief Callback function for handling pairing failure.
 * 
 * This function is called when the pairing process fails.
 * 
 * @param conn Pointer to the connection object for which the pairing process has failed.
 * 
 * @param reason The reason code indicating the cause of the pairing failure.
 * 
 */ 
static void pairing_failed(struct bt_conn *conn, enum bt_security_err reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing failed conn: %s, reason %d\n", addr, reason);
}

static const struct bt_conn_auth_cb auth_callbacks = {
	.cancel = auth_cancel
};

static struct bt_conn_auth_info_cb conn_auth_info_callbacks = {
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed
};


