/*
 * Copyright (c) 2012-2014 Wind River Systems, Inc.
 *
 * SPDX-License-Identifier: Apache-2.0
 */


#include <zephyr/types.h>
#include <stddef.h>
#include <inttypes.h>
#include <errno.h>
#include <zephyr/sys/printk.h>
#include <zephyr/kernel.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/hci.h>
#include <bluetooth/scan.h>
#include <bluetooth/gatt_dm.h>

#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/bluetooth/services/hrs.h>
#include <bluetooth/services/hrs_client.h>

#include <dk_buttons_and_leds.h>

#include <zephyr/settings/settings.h>
#include <zephyr/logging/log.h>

#include <stdio.h>
#include <stdlib.h>

//#include "hrs_central.h"
#include "hr_service_central.c"




//
//char addr1[BT_ADDR_LE_STR_LEN];


void main(void)
{
	int err;
printk("starting bluetooth central heart rate example\n");

err=bt_hrs_client_init(&hrs_c);
	if(err)
	{
		printf("heart rate service client failed to init(err %d)\n",err);
		return;
	}

err=bt_enable(NULL);
	if(err){
		printk("bluetooth init failed(err %d)\n",err);
		return;
	}
 
printk("bluetooth initialed\n");


if(IS_ENABLED(CONFIG_SETTINGS)){
	settings_load();
}


	err = bt_conn_auth_cb_register(&auth_callbacks);
	if (err) {
		printk("Failed to register authorization callbacks.\n");
		return;
	}


	
   err = dk_buttons_init(button_handler);
	if(err)
	{
		printk("failed to initialize buttons(err %d)\n",err);
		return;
	}

}
