#ifndef CUSTOMFILE_H
#define CUSTOMFILE_H


#include <zephyr/bluetooth/conn.h>
#include <bluetooth/gatt_dm.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/sys/atomic.h>

#define STACKSIZE 1024
#define PRIORITY 7

#define RUN_STATUS_LED             DK_LED1
#define CENTRAL_CON_STATUS_LED	   DK_LED2
#define PERIPHERAL_CONN_STATUS_LED DK_LED3

#define RUN_LED_BLINK_INTERVAL 1000

#define CUSTOM_SERVICE_QUEUE_SIZE 16

#ifndef CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW_AUTHEN
#define CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW_AUTHEN 0
#endif
#ifndef CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW_ENCRYPT
#define CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW_ENCRYPT 0
#endif
#ifndef CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW
#define CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW 0
#endif

/*specifies the default permissions for a custom service*/
#define CUSTOM_GATT_PERM_DEFAULT (						\
	CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW_AUTHEN ?				\
	(BT_GATT_PERM_READ_AUTHEN | BT_GATT_PERM_WRITE_AUTHEN) :	\
	CONFIG_BT_CUSTOM_SERVICE_DEFAULT_PERM_RW_ENCRYPT ?				\
	(BT_GATT_PERM_READ_ENCRYPT | BT_GATT_PERM_WRITE_ENCRYPT) :	\
	(BT_GATT_PERM_READ | BT_GATT_PERM_WRITE))


/**
 * @brief characteristic1 measurement UUID value
*/
#define BT_UUID_CHAR1_MEASUREMENT_VAL  0x1123
/**
 *  @brief Characteristic1 Measurement 
 */
#define BT_UUID_CHAR1_MEASUREMENT \
	BT_UUID_DECLARE_16(BT_UUID_CHAR1_MEASUREMENT_VAL)


/**
 *  @brief Characteristic2 measurment UUID value
 */
#define BT_UUID_CHAR2_MEASUREMENT_VAL  0x1124 
/**
 *  @brief Characteristic2 Measurement Interval
 */
#define BT_UUID_CHAR2_MEASUREMENT \
	BT_UUID_DECLARE_16(BT_UUID_CHAR2_MEASUREMENT_VAL)

/** 
 * @brief custom service UUID value
*/
#define BT_UUID_CUSTOM_SERVICE_VAL 0x1122
/**
 *  @brief custom service 
 */
#define BT_UUID_CUSTOM_SERVICE \
	BT_UUID_DECLARE_16(BT_UUID_CUSTOM_SERVICE_VAL)


/**@brief data structure of the Characteristic2 measurment charecteristics.
 * */ 
struct bt_custom_service_value_measurement{

/**characteristic2 measurment value. */
	uint16_t value;	
};	


struct bt_custom_service_value;

/**@brief custom service measurment notification callback.
 *
 * This function called every time when client recieve a notification
 * with custome service measurment data.
 * 
 * 
 *  @param[in] custom_c custom service client instance 
 *  @param[in] val cutom service recieved data. 
 *  @param[in] err 0 if the notification is valid.
 * 					otherwise ,contains a (negative) error code.
 * 
 */
typedef void(*bt_custom_service_client_notify_cb)(struct bt_custom_service_client *custom_c,
					const struct bt_custom_service_value_measurement *val,
int err);


/**@brief Characteristic2  measurment  structure.
 */
struct bt_custom_client_char2_meas{
	/** value handle.*/
	uint16_t handle;

	/**Handle of the characteristic CCC descriptor.*/
	uint16_t ccc_handle;

	/** Notification callback. */
	bt_custom_service_client_notify_cb notify_cb;
};


/**@brief custome service client instance structure.
 * this structure contains status information for the client.
 */ 
struct bt_custom_service_client{
	
	/** Connection object. */
	struct bt_conn *conn;

	/** characteristic2 of the characteristic.*/
	struct bt_custom_client_char2_meas measurement_char;
}; 


/**@brief subscribe to Characteristic2  measurment notification.
 * 
 * this function writes ccc descriptor of the Characteristic2  measument charecteristics
 * to enable notification 
 * @param[in] custom_c custom service client instance. 
 * @param[in] notify_cb  notification callback.
 *  
 * @return 0 if the operation was successful.
 * 			 otherwise, a (negative) error code is returned.
 */ 
int bt_custom_client_measurment_subscribe(struct bt_custom_service_client *custom_c,
bt_custom_service_client_notify_cb notify_cb);


#endif