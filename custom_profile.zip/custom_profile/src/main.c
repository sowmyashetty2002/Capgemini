/*
 * 
 * Implemented custom service profile, 
 * With a custom service and characteristics.
 * 
 *
 */

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <bluetooth/gatt_dm.h>
#include <bluetooth/scan.h>

#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/bluetooth/services/hrs.h>
#include <bluetooth/services/hrs_client.h>

#include <dk_buttons_and_leds.h>

#include <zephyr/settings/settings.h>

#include <zephyr/kernel.h>
#include <stdio.h>
#include <stdlib.h>

#include "custom_service_profile.h"


/**@brief Bluetooth Advertising Data
 * 
 * This structure defines the bluetooth advertising data used 
 * for broadcasting information about the device.It includes the
 * device appearance,flags,supported UUIDs, and the device name.
 *
 */
static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_GAP_APPEARANCE,
		(CONFIG_BT_DEVICE_APPEARANCE >> 0) & 0xff,
		(CONFIG_BT_DEVICE_APPEARANCE >> 8) & 0xff),
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA_BYTES(BT_DATA_UUID16_ALL,
		      BT_UUID_16_ENCODE(BT_UUID_HRS_VAL)), /* custom Service */
};


/**@brief scan response data defination.
 * 
 * It include the complete local name of the device.
 * 
 */  
static const struct bt_data sd[] = {
	BT_DATA_BYTES(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME)
};



K_MSGQ_DEFINE(custom_service_queue, sizeof(struct bt_custom_service_value_measurement), CUSTOM_SERVICE_QUEUE_SIZE,4);


static struct bt_hrs_client hrs_c;
static struct bt_conn *central_conn;

/**@brief  Callback function for receiving custom service char2 Measurement notifications.
 * 
 * @param custom_c  The custom service client instance.
 * 
 * @param val Pointer to the custom service char2 Measurement structure containing 
 * 			the received measurement data.
 * 
 * @param err  The error code (0 if no error occurred).
 * 
 */ 
static void custom_measurement_notify_cb(struct bt_custom_service_client *custom_c,
					const struct bt_custom_service_value_measurement *val,
int err)

{
	if (err) {
		printk("Error during receiving characteristic2 Measurement notification, err: %d\n",
			err);
		return;
	}

	printk("characteristic2 Measurement notification received:\n\n");
	printk("\n\tcharacteristic2 Measurement Value: %d gm3/n", val->value);
	printk("\n");
	err = k_msgq_put(&custom_service_queue, val, K_NO_WAIT);
	if (err) {
		printk("Notification queue is full. Discarting characteristic2 notification (err %d)\n", err);
	}
}

/**@brief Callback function for the completion of GATT service discovery
 * 
 * @param dm  Discovery instance.
 * 
 * @param context  The user context.
 * 
 */
static void discovery_completed_cb(struct bt_gatt_dm *dm,
				   void *context)
{
	int err;

	printk("The discovery procedure succeeded\n");

	bt_gatt_dm_data_print(dm);

	err = bt_hrs_client_handles_assign(dm, &hrs_c);
	if (err) {
		printk("Could not init HRS client object (err %d)\n", err);
		return;
	}

}


/**@brief Callback function for handling the failure to find the custom service 
 *        during GATT service discovery.
 * 
 * @param conn Pointer to the connection object associated with the failed discovery.
 * 
 * @param context User-defined context data.
 * 
 */
static void discovery_not_found_cb(struct bt_conn *conn,
				   void *context)
{
	printk("Heart Rate Service could not be found during the discovery\n");
}


/**@brief Callback function for handling errors encountered during GATT service discovery.
 * 
 * @param conn Pointer to the connection object associated with the failed discovery.
 * 
 * @param err The error code indicating the reason for the discovery failure.
 * 
 * @param context  User-defined context data.
 * 
 */
static void discovery_error_found_cb(struct bt_conn *conn,
				     int err, void *context)
{
	printk("The discovery procedure failed with %d\n", err);
}

static const struct bt_gatt_dm_cb discovery_cb = {
	.completed = discovery_completed_cb,
	.service_not_found = discovery_not_found_cb,
	.error_found = discovery_error_found_cb
};


/**@brief Function for initiating GATT service discovery.
 * 
 * This function starts the GATT service discovery procedure for the specified connection.
 * 
 * @param conn Pointer to the connection object for which GATT service discovery is to be initiated.
 * 
 */ 
static void gatt_discover(struct bt_conn *conn)
{
	int err;

	err = bt_gatt_dm_start(conn, BT_UUID_HRS, &discovery_cb, NULL);
	if (err) {
		printk("Could not start the discovery procedure, error "
			   "code: %d\n", err);
	}
}


/**@brief Authentication cancellation callback function.
 * 
 * This function is called when authentication process is
 * cancelled for a bluetooth connection.
 * 
 * @param[in] conn Pointer to the bluetooth connection for which 
 *            authentication process was cancelled.
 * 
 */ 
static void auth_cancel(struct bt_conn *conn)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing cancelled: %s\n", addr);
}

/**@brief pairing completion callback function
 * 
 * This function is called when the pairing process is completed
 * for a bluetooth connection.
 * 
 * @param[in] conn pointer to a bluetooth connection for which
 *             the pairing process has been completed.
 *  
 * @param[in] bonded Boolean flag indicating whether the device 
 *            are bonded or not.
 *            true:Device are bonded.
 *            false:Device are not bonded.
 */
static void pairing_complete(struct bt_conn *conn, bool bonded)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing completed: %s, bonded: %d\n", addr, bonded);
}


/**brief  pairing failure callback function
 * 
 * This function is called when the pairing process fails for 
 * a bluetooth connection.
 * 
 * @param[in] conn pointer to the bluetooth connection for which 
 *            the pairing process has failed. 
 * 
 * 
 * @param[in] reason The reason code indicating the specific cause
 *            of the pairing failure.  
 * 
 */
static void pairing_failed(struct bt_conn *conn, enum bt_security_err reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing failed conn: %s, reason %d\n", addr, reason);
}


/**@brief connection authentication callback structure.
 * 
 * This structure defines the callback function for 
 * handling connection authentication cancellation.
 * 
 */
static const struct bt_conn_auth_cb auth_callbacks = {
	.cancel = auth_cancel
};

/**@brief Connection authentication information callback structure.
 * It defines the callback functions to handle connection 
 * authentication information.
 * such as pairing completion and pairing failure.
 *
 */
static struct bt_conn_auth_info_cb conn_auth_info_callbacks = {
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed
};

/**@brief Function for starting the Bluetooth scanning process.
 * 
 * @return 0 on success ,or negative error code if the scan 
 *           start operation fails.
 * 
 */
static int scan_start(void)
{
	int err = bt_scan_start(BT_SCAN_TYPE_SCAN_PASSIVE);

	if (err) {
		printk("Scanning failed to start (err %d)\n", err);
	}

	return err;
}

/**@brief connection establishment callback function
 * 
 * @param[in] conn pointer to the bluetooth connection
 *  
 * @param[in] conn_err Connection error code
 *            0: Connection established successfully.
 *            Non-Zero: Connection error code.
 */ 
static void connected(struct bt_conn *conn, uint8_t conn_err)
{
	int err;
	struct bt_conn_info info;
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (conn_err) {
		printk("Failed to connect to %s (%u)\n", addr, conn_err);

		if (conn == central_conn) {
			bt_conn_unref(central_conn);
			central_conn = NULL;

			scan_start();
		}

		return;
	}

	printk("Connected: %s\n", addr);

	bt_conn_get_info(conn, &info);

	if (info.role == BT_CONN_ROLE_CENTRAL) {
		dk_set_led_on(CENTRAL_CON_STATUS_LED);

		err = bt_conn_set_security(conn, BT_SECURITY_L2);
		if (err) {
			printk("Failed to set security (err %d)\n", err);

			gatt_discover(conn);
		}
	} else {
		dk_set_led_on(PERIPHERAL_CONN_STATUS_LED);
	}
}


/**@brief Disconnection callback function.
 * 
 * This function is called when a bluetooth connection 
 * is disconnected.
 * 
 * @param[in] conn Pointer to the Bluetooth connection that was
 *            Disconnected.  
 * 
 * @param[in] reason Reason code indicating the cause of disconnection.
 * 
 * 
 */ 
static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Disconnected: %s (reason %u)\n", addr, reason);

	if (conn == central_conn) {
		dk_set_led_off(CENTRAL_CON_STATUS_LED);

		bt_conn_unref(central_conn);
		central_conn = NULL;

		scan_start();
	} else {
		dk_set_led_off(PERIPHERAL_CONN_STATUS_LED);
	}
}


/**@brief Security changed callback function.
 * 
 * @param[in] conn Pointer to the bluetooth connection for which
 *            security level changed.
 * 
 * @param[in] level New security level for the connection.
 * 
 * @param[in]err Security error code
 *               0:security level changed successfully.
 *               Non-zero:security level error code.
 * 
 */  
static void security_changed(struct bt_conn *conn, bt_security_t level,
			     enum bt_security_err err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (!err) {
		printk("Security changed: %s level %u\n", addr, level);
	} else {
		printk("Security failed: %s level %u err %d\n", addr, level,
			err);
	}

	if (conn == central_conn) {
		gatt_discover(conn);
	}
}


/**@brief connection callback for Bluetooth 
 *  connection event.
 * 
 * This defines the callback function to handle various Bluetooth 
 * connection event such as connection establishment,disconnection,
 * and security changes. 
 * 
 */
BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected = connected,
	.disconnected = disconnected,
	.security_changed = security_changed
};

/**@brief callback function for handling the scan filter match.
 * 
 * @param device_info Pointer to the device information structure containing
 *                    details about the matched device.
 * 
 * @param filter_match Pointer to the scan filter match structure containing 
 *                     information about the matched filter.
 *         
 * @param connectable Boolean indicating whether the device is connectable or not.
 * 
 * 
 */ 
static void scan_filter_match(struct bt_scan_device_info *device_info,
			      struct bt_scan_filter_match *filter_match,
			      bool connectable)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(device_info->recv_info->addr, addr, sizeof(addr));

	printk("Filters matched. Address: %s connectable: %d\n",
		   addr, connectable);
}

/**@brief callback function for handling the connecting error during scanning.
 * 
 * @param device_info Pointer to the device information structure containing 
 *                    details about the device that failed to connect.
 * 
 */
static void scan_connecting_error(struct bt_scan_device_info *device_info)
{
	printk("Connecting failed\n");
}

/**@brief callback function for handling successful connection establishment 
 *        during scanning.
 * 
 * @param device_info Pointer to the device information structure containing 
 *                    details about the connected device.
 * 
 * @param conn Pointer to the established connection object.
 * 
 */ 
static void scan_connecting(struct bt_scan_device_info *device_info,
			    struct bt_conn *conn)
{
	central_conn = bt_conn_ref(conn);
}

BT_SCAN_CB_INIT(scan_cb, scan_filter_match, NULL,
		scan_connecting_error, scan_connecting);

/**@brief Function for initiating bluetooth scanning.
 * 
 * This function initializes bluetooth scanning by setting up the scan parameters,
 * registering the scan callbacks,added the scan filter, and enabling the scan filter.
*/  
static void scan_init(void)
{
	int err;

	struct bt_scan_init_param param = {
		.scan_param = NULL,
		.conn_param = BT_LE_CONN_PARAM_DEFAULT,
		.connect_if_match = 1
	};

	bt_scan_init(&param);
	bt_scan_cb_register(&scan_cb);

	err = bt_scan_filter_add(BT_SCAN_FILTER_TYPE_UUID, BT_UUID_HRS);
	if (err) {
		printk("Scanning filters cannot be set (err %d)\n", err);
	}

	err = bt_scan_filter_enable(BT_SCAN_UUID_FILTER, false);
	if (err) {
		printk("Filters cannot be turned on (err %d)\n", err);
	}
}


/**@brief custom service notification thread function.
 * 
 * This function continuosly sends a hardcoded value
 * as a notifications using the custom service.
 * 
 */
static void custom_notify_thread(void)
{
	struct bt_custom_service_value_measurement val;
	uint16_t hardcoded_value=50;
	while(1)
	{
		bt_cs_notify(hardcoded_value);
		k_sleep(K_SECONDS(2));
	}
}

void main(void)
{
	int err;
	int blink_status = 0;
	printk("Starting Bluetooth Central and Peripheral Heart Rate relay example\n");

	err = dk_leds_init();
	if (err) {
		printk("LEDs init failed (err %d)\n", err);
		return;
	}
	err = bt_conn_auth_cb_register(&auth_callbacks);
	if (err) {
		printk("Failed to register authorization callbacks.\n");
		return;
	}

	err = bt_conn_auth_info_cb_register(&conn_auth_info_callbacks);
	if (err) {
		printk("Failed to register authorization info callbacks.\n");
		return;
	}

	err = bt_enable(NULL);
	if (err) {
		return;
	}

	if (IS_ENABLED(CONFIG_SETTINGS)) {
		settings_load();
	}

	err = bt_hrs_client_init(&hrs_c);
	if (err) {
		printk("Heart Rate Service client failed to init (err %d)\n", err);
		return;
	}

	scan_init();

	err = scan_start();
	if (err) {
		return;
	}

	printk("Scanning started\n");

	err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad),
			      sd, ARRAY_SIZE(sd));
	if (err) {
		printk("Advertising failed to start (err %d)\n", err);
		return;
	}

	printk("Advertising started\n");

	for (;;) {
		dk_set_led(RUN_STATUS_LED, (++blink_status) % 2);
		k_sleep(K_MSEC(RUN_LED_BLINK_INTERVAL));
	}
}

K_THREAD_DEFINE(custom_notify_thread_id, STACKSIZE, custom_notify_thread,
		NULL, NULL, NULL, PRIORITY, 0, 0);
