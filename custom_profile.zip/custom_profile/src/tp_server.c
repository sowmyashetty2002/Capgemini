/** @file
 *  @brief Custom service sample
*/

/*
 * 
 * Implemented custom service profile, 
 * With a custom service and characteristics.
 * 
 *
 */

#include <zephyr/types.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <stdint.h>

#include <stdio.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>

#include "custom_service_profile.h"

#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(cs);


/**@brief Callback function for the custom service characteristic2 
 *         client configuration descriptor (CCC) change. 
 * 
 * @param[in] attr pointer to the BT GATT attribute  
 * 
 *  @param[in] value  The new value of the CCC descriptor
 * 
 */
static void custom_ccc_cfg_changed(const struct bt_gatt_attr *attr, uint16_t value)
{
	

	ARG_UNUSED(attr);
	
	bool notif_enabled = (value == BT_GATT_CCC_NOTIFY);
	
	LOG_INF("CHARACTERISTIC2 notifications %s", notif_enabled ? "enabled" : "disabled");

}


/**@brief Read callback function for the custom
 *        characteristic1. 
 * 
 * @param[in] conn pointer to the bluetooth connection object. 
 * 
 * @param[in] attr pointer to the BT GATT attribute
 * @param[in] buf pointer to the buffer where
 *            the value will be copied 
 * @param[in] len length of the buffer 
 * 
 * @param[in] offset offset within the attribute value from which
 *            to start copying  
 * @return The number of bytes copied into the buffer
 */ 
static ssize_t read_char(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                         void *buf, uint16_t len, uint16_t offset)
{
    uint16_t hardcoded_value=0x01;
    ssize_t hardcoded_len = sizeof(hardcoded_value);
    if (offset > hardcoded_len) {
        return BT_GATT_ERR(BT_ATT_ERR_INVALID_OFFSET);
    }
    ssize_t read_len = MIN(len, hardcoded_len - offset);
    memcpy(buf, (uint8_t *)&hardcoded_value + offset, read_len);
    return read_len;
}



 
/**@brief write callback function for custom characteristic.
 * @param[in] conn pointer to the bluetooth connection object. 
 * 
 * @param[in] attr pointer to the BT GATT attribute being written. 
 * 
 * @param[in] buf  pointer to the buffer containing 
 *            the value to be written.
 * 
 * @param[in] len length of the buffer.
 * 
 * @param[in] offset within the attribute value from which to start writing. 
 * 
 * @param[in] flags write flags indicating the additional write
 * 			   parameters.
 * 
 * @return  The number of bytes written.
 */
static ssize_t write_char(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                          const void *buf, uint16_t len, uint16_t offset, uint8_t flags)
{
    const int16_t *value_ptr = (const int16_t *)buf;
    for (uint16_t i = 0; i < len / sizeof(int16_t); i++) {
        printf("%d", value_ptr[i]);
    }
    return len;
}


/* custom service declaration */
BT_GATT_SERVICE_DEFINE(cs_svc,
	BT_GATT_PRIMARY_SERVICE(BT_UUID_CUSTOM_SERVICE),
	BT_GATT_CHARACTERISTIC(BT_UUID_CHAR1_MEASUREMENT, BT_GATT_CHRC_READ | BT_GATT_CHRC_WRITE_WITHOUT_RESP,
			       BT_GATT_PERM_READ | BT_GATT_PERM_WRITE, read_char, write_char, NULL),
	BT_GATT_CHARACTERISTIC(BT_UUID_CHAR2_MEASUREMENT, BT_GATT_CHRC_NOTIFY,
			       BT_GATT_PERM_NONE, NULL, NULL, NULL),
	BT_GATT_CCC(custom_ccc_cfg_changed,
		    CUSTOM_GATT_PERM_DEFAULT),
);


/**@brief initialize the cs subsystem.
 *  
 * @param[in] dev pointer to the device structure.
 *  
 * @return 0 on success,negative error code on failure.
 */ 
static int cs_init(const struct device *dev)
{
	ARG_UNUSED(dev);

	return 0;
}


/**@brief notification function to send a notification to the client 
 *                     about a charecteristic2 measurment value.
 * 
 * @param[in] chara2 charecteristic2 measurment value.
 *  
 * @return 0 if the connection with the gatt client is not proper
 *           otherwise it returns value.
 */
int bt_cs_notify(uint16_t chara_2)
{
	int rc;
	static uint8_t cs_char2[2];

	cs_char2[0] = 0x01;  
	cs_char2[1] = chara_2;

	rc = bt_gatt_notify(NULL, &cs_svc.attrs[4], &cs_char2, sizeof(cs_char2));

	return rc == -ENOTCONN ? 0 : rc;
}


SYS_INIT(cs_init, APPLICATION, CONFIG_APPLICATION_INIT_PRIORITY);