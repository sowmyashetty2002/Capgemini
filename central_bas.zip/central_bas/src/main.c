/**
 *  @file main.c
 *  @brief Battery service main function.
 * 
 * This application demonstrates a server-side functionality for a Battery Service.
 * 
 * The main function initializes the application, sets up the necessary Bluetooth configurations, and starts advertising
 * the Battery Service. It also handles connection events, pairing, security changes, and disconnections through the defined
 * callback functions. Additionally, it includes a battery notification thread that continuously sends a hardcoded battery
 * level value as a notification using the Battery Service.
 * 
 */

#include <zephyr/types.h>
#include <stddef.h>
#include <inttypes.h>
#include <errno.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <bluetooth/gatt_dm.h>
#include <bluetooth/scan.h>
#include <bluetooth/services/bas_client.h>
#include <dk_buttons_and_leds.h>

#include <zephyr/settings/settings.h>
#include <zephyr/logging/log.h>

#include "bas_server.h"


/**
 * @brief Bluetooth Advertising Data
 * 
 * This structure defines the bluetooth advertising data used 
 * for broadcasting information about the device.It includes the
 * device appearance,flags,supported UUIDs, and the device name.
 *
 */ 
static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_GAP_APPEARANCE,
		(CONFIG_BT_DEVICE_APPEARANCE >> 0) & 0xff,
		(CONFIG_BT_DEVICE_APPEARANCE >> 8) & 0xff),
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA_BYTES(BT_DATA_UUID16_ALL,
		      BT_UUID_16_ENCODE(BT_UUID_BAS_VAL)),
};

/**
 * @brief scan response data defination.
 * 
 * It include the complete local name of the device.
 * 
 */  
static const struct bt_data sd[] = {
	BT_DATA_BYTES(BT_DATA_NAME_COMPLETE, CONFIG_BT_DEVICE_NAME)
};

K_MSGQ_DEFINE(battery_service_queue, sizeof(struct bt_battery_value_measurment), BATTERY_SERVICE_QUEUE_SIZE,4);


/**
 * @brief Bluetooth peripheral connection.
 * 
 * It is a pointer to a structure of type 'bt_conn' that holds the 
 * information about the connection. 
 * 
 */ 
static struct bt_conn *peripheral_conn;


/**
 * @brief Authentication cancellation callback function.
 * 
 * This function is called when authentication process is
 * cancelled for a bluetooth connection.
 * 
 * @param[in] conn Pointer to the bluetooth connection for which 
 *            authentication process was cancelled.
 * 
 */ 
static void auth_cancel(struct bt_conn *conn)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing cancelled: %s\n", addr);
}

/**
 * @brief pairing completion callback function
 * 
 * This function is called when the pairing process is completed
 * for a bluetooth connection.
 * 
 * @param[in] conn pointer to a bluetooth connection for which
 *             the pairing process has been completed.
 *  
 * @param[in] bonded Boolean flag indicating whether the device 
 *            are bonded or not.
 *            true:Device are bonded.
 *            false:Device are not bonded.
 */
static void pairing_complete(struct bt_conn *conn, bool bonded)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing completed: %s, bonded: %d\n", addr, bonded);
}

/**
 * @brief  pairing failure callback function
 * 
 * This function is called when the pairing process fails for 
 * a bluetooth connection.
 * 
 * @param[in] conn pointer to the bluetooth connection for which 
 *            the pairing process has failed. 
 * 
 * 
 * @param[in] reason The reason code indicating the specific cause
 *            of the pairing failure.  
 * 
 */  
static void pairing_failed(struct bt_conn *conn, enum bt_security_err reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Pairing failed conn: %s, reason %d\n", addr, reason);
}

/**
 * @brief connection authentication callback structure.
 * 
 * This structure defines the callback function for 
 * handling connection authentication cancellation.
 * 
 */
static const struct bt_conn_auth_cb auth_callbacks = {
	.cancel = auth_cancel
};

/**
 * @brief Connection authentication information callback structure.
 * It defines the callback functions to handle connection 
 * authentication information.
 * such as pairing completion and pairing failure.
 *
 */
static struct bt_conn_auth_info_cb conn_auth_info_callbacks = {
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed
};

/**
 * @brief connection establishment callback function
 * 
 * @param[in] conn pointer to the bluetooth connection
 *  
 * @param[in] conn_err Connection error code
 *            0: Connection established successfully.
 *            Non-Zero: Connection error code.
 */ 
static void connected(struct bt_conn *conn, uint8_t conn_err)
{
	int err;
	struct bt_conn_info info;
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (conn_err) {
		printk("Failed to connect to %s (%u)\n", addr, conn_err);
		return;
	}

	printk("Connected: %s\n", addr);

	bt_conn_get_info(conn, &info);

	if (info.role == BT_CONN_ROLE_CENTRAL) {
		dk_set_led_on(PERIPHERAL_CONN_STATUS_LED);
		err = bt_conn_set_security(conn, BT_SECURITY_L2);
		
		if (err) {
			printk("Failed to set security (err %d)\n", err);
		}
	}
}

/**
 * @brief Disconnection callback function.
 * 
 * This function is called when a bluetooth connection 
 * is disconnected.
 * 
 * @param[in] conn Pointer to the Bluetooth connection that was
 *            Disconnected.  
 * 
 * @param[in] reason Reason code indicating the cause of disconnection.
 * 
 * 
 */ 
static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	printk("Disconnected: %s (reason %u)\n", addr, reason);

	if (conn == peripheral_conn) {
		dk_set_led_off(PERIPHERAL_CONN_STATUS_LED);

		bt_conn_unref(peripheral_conn);
		peripheral_conn = NULL;
	}
}

/**
 * @brief Security changed callback function.
 * 
 * @param[in] conn Pointer to the bluetooth connection for which
 *            security level changed.
 * 
 * @param[in] level New security level for the connection.
 * 
 * @param[in] err Security error code
 *               0:security level changed successfully.
 *               Non-zero:security level error code.
 * 
 */  
static void security_changed(struct bt_conn *conn, bt_security_t level,
			     enum bt_security_err err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (!err) {
		printk("Security changed: %s level %u\n", addr, level);
	} else {
		printk("Security failed: %s level %u err %d\n", addr, level,
			err);
	}
}

/**
 * @brief connection callback for Bluetooth 
 *  connection event.
 * 
 * This defines the callback function to handle various Bluetooth 
 * connection event such as connection establishment,disconnection,
 * and security changes. 
 * 
 */
BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected = connected,
	.disconnected = disconnected,
	.security_changed = security_changed
};

/**
 * @brief Battery service notification thread function.
 * 
 * This function continuosly sends a hardcoded battery level value
 * as a notifications using the battery service.
 * 
 */
static void battery_notify_thread(void)
{
	struct  bt_battery_value_measurment val;
	uint16_t total_value;
	uint16_t hardcoded_value=50;
	while(1)
	{
		 bt_bs_notify(total_value);
		 k_sleep(K_SECONDS(2));
	}

}

void main(void)
{
	int err;
	int blink_status = 0;
	printk("Starting Bluetooth Peripheral Battery service example\n");

	err = dk_leds_init();
	if (err) {
		printk("LEDs init failed (err %d)\n", err);
		return;
	}
	
	err = bt_conn_auth_cb_register(&auth_callbacks);
	if (err) {
		printk("Failed to register authorization callbacks.\n");
		return;
	}

	err = bt_conn_auth_info_cb_register(&conn_auth_info_callbacks);
	if (err) {
		printk("Failed to register authorization info callbacks.\n");
		return;
	}

	err = bt_enable(NULL);
	if (err) {
		return;
	}

	if (IS_ENABLED(CONFIG_SETTINGS)) {
		settings_load();
	}
	err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad),
			      sd, ARRAY_SIZE(sd));
				
	if (err) {
		printk("Advertising failed to start (err %d)\n", err);
		return;
	}

	printk("Advertising started\n");

	for (;;) {
		dk_set_led(RUN_STATUS_LED, (++blink_status) % 2);
		k_sleep(K_MSEC(RUN_LED_BLINK_INTERVAL));
	}
}

K_THREAD_DEFINE(battery_notify_thread_id, STACKSIZE, battery_notify_thread,
		NULL, NULL, NULL, PRIORITY, 0, 0);
