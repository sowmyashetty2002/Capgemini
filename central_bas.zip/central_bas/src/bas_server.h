/**
 *  @file bas_server.h
 *  @brief Header file for Battery service for peripheral.
 */

#ifndef BAS_SERVER_H
#define BAS_SERVER_H

#include <zephyr/bluetooth/conn.h>
#include <bluetooth/gatt_dm.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/sys/atomic.h>

#define RUN_STATUS_LED             DK_LED1
#define PERIPHERAL_CONN_STATUS_LED DK_LED3

#define RUN_LED_BLINK_INTERVAL 1000
#define PRIORITY 7

#define STACKSIZE 1024
#define BATTERY_SERVICE_QUEUE_SIZE 16

#ifndef CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW_AUTHEN
#define CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW_AUTHEN 0
#endif
#ifndef CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW_ENCRYPT
#define CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW_ENCRYPT 0
#endif
#ifndef CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW
#define CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW 0
#endif

#define BATTERY_GATT_PERM_DEFAULT (						\
	CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW_AUTHEN ?				\
	(BT_GATT_PERM_READ_AUTHEN | BT_GATT_PERM_WRITE_AUTHEN) :	\
	CONFIG_BT_BATTERY_SERVICE_DEFAULT_PERM_RW_ENCRYPT ?				\
	(BT_GATT_PERM_READ_ENCRYPT | BT_GATT_PERM_WRITE_ENCRYPT) :	\
	(BT_GATT_PERM_READ | BT_GATT_PERM_WRITE))


#define BT_UUID_BATTERY_SERVICE_VAL  0x180F
/**
 *  UUID for battery service.
 */
#define BT_UUID_BATTERY_SERVICE \
	BT_UUID_DECLARE_16(BT_UUID_BATTERY_SERVICE_VAL)


#define BT_UUID_BATTERY_LEVEL_MEASUREMENT_VAL  0x2A19
/**
 *  Battery level characteristic UUID value.
 */
#define BT_UUID_BATTERY_LEVEL_MEASUREMENT \
	BT_UUID_DECLARE_16(BT_UUID_BATTERY_LEVEL_MEASUREMENT_VAL)


struct bt_battery_value;


/**
 * @brief data structure of the Battery level measurment charecteristics.
 * 
 */ 
struct bt_battery_value_measurment{

	/**Battery level measurment value. */
	uint16_t battery_val;
};


/**
 * @brief Battery Level characteristic measurment  structure.
 * 
 */ 
struct bt_battery_value{

	/** value handle.*/
	uint16_t handle;

	/**Handle of the characteristic CCC descriptor.*/
	uint16_t ccc_handle;
};

#endif