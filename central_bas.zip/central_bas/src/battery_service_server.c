/** 
 *  @file battery_service_server.c
 *  @brief Implementation of Battery service for server side.
 * 
 *  This file contains the implementation of Battery service functionalities for server side.This 
 *  program defines advertisement data,required UUIDs, service and characteristics.
 * 
 */

#include <zephyr/types.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <stdint.h>

#include <stdio.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include "bas_server.h"

#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(bas);


/**
 * @brief Callback function for the battery level measurment characteristic
 *         client configuration descriptor (CCC) change. 
 * 
 * @param[in] attr pointer to the BT GATT attribute  
 * 
 * @param[in] value  The new value of the CCC descriptor
 * 
 */
static void battery_ccc_cfg_changed(const struct bt_gatt_attr *attr, uint16_t value)
{
	ARG_UNUSED(attr);
	bool notif_enabled = (value == BT_GATT_CCC_NOTIFY);
	LOG_INF("battery level notifications %s\n", notif_enabled ? "enabled" : "disabled");

}

/**
 * @brief Read callback function for battery level characteristic. 
 * 
 * @param[in] conn pointer to the bluetooth connection object. 
 * 
 * @param[in] attr pointer to the BT GATT attribute
 * 
 * @param[in] buf pointer to the buffer where
 *            the value will be copied 
 * 
 * @param[in] len length of the buffer 
 * 
 * @param[in] offset offset within the attribute value from which
 *            to start copying  
 * @return The number of bytes copied into the buffer
 */ 
static ssize_t read_char(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                         void *buf, uint16_t len, uint16_t offset)

{
    uint16_t hardcoded_value=0x50;
    ssize_t hardcoded_len = sizeof(hardcoded_value);
    if (offset > hardcoded_len) {
        return BT_GATT_ERR(BT_ATT_ERR_INVALID_OFFSET);
    }
    ssize_t read_len = MIN(len, hardcoded_len - offset);
    memcpy(buf, (uint8_t *)&hardcoded_value + offset, read_len);
    return read_len;
}

/* battery service declaration */
BT_GATT_SERVICE_DEFINE(bas_svc,
	BT_GATT_PRIMARY_SERVICE(BT_UUID_BATTERY_SERVICE),
	BT_GATT_CHARACTERISTIC(BT_UUID_BATTERY_LEVEL_MEASUREMENT , BT_GATT_CHRC_READ | BT_GATT_CHRC_NOTIFY,
			       BT_GATT_PERM_READ | BT_GATT_PERM_NONE, read_char, NULL, NULL),
	BT_GATT_CCC(battery_ccc_cfg_changed,
		    BATTERY_GATT_PERM_DEFAULT),
);

/**
 * @brief initialize the 'bas' subsystem.
 *  
 * @param[in] dev pointer to the device structure.
 *  
 * @return 0 on success,negative error code on failure.
 */ 
static int bas_init(const struct device *dev)
{
	ARG_UNUSED(dev);

	return 0;
}

/**
 * @brief notification function to send a notification to the client 
 *                     about a battery level measurment value.
 * 
 * @param[in] battery_val batttery level measurment value.
 * 
 * @return 0 if the connection with the gatt client is not proper
 *           otherwise it returns value.
 * 
 */
int bt_bs_notify(uint16_t battery_val)
{
	int rc;
	static uint8_t bas_arr[2];
    
	bas_arr[0] = 0x50;  
	bas_arr[1] = battery_val;

	rc = bt_gatt_notify(NULL, &bas_svc.attrs[2], &bas_arr, sizeof(bas_arr));

	return rc == -ENOTCONN ? 0 : rc;
}

SYS_INIT(bas_init, APPLICATION, CONFIG_APPLICATION_INIT_PRIORITY);
